
package com.smarterp.controller;

import com.smarterp.entity.Leave;
import com.smarterp.repository.LeaveRepository;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/leaves")
public class LeaveController {

    private final LeaveRepository repository;

    public LeaveController(LeaveRepository repository) {
        this.repository = repository;
    }

    // Get all leaves
    @GetMapping
    public List<Leave> getAllLeaves() {
        return repository.findAll();
    }

    // Get leave by ID
    @GetMapping("/{id}")
    public Leave getLeave(@PathVariable Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Leave not found"));
    }

    // Get leaves by employee
    @GetMapping("/employee/{employeeId}")
    public List<Leave> getByEmployee(
            @PathVariable Long employeeId) {
        return repository.findByEmployeeId(employeeId);
    }

    // Get leaves by status
    @GetMapping("/status/{status}")
    public List<Leave> getByStatus(
            @PathVariable String status) {
        return repository.findByStatus(status);
    }

    // Apply leave
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Leave applyLeave(@Valid @RequestBody Leave leave) {
        leave.setId(null);
        leave.setStatus("Pending");
        return repository.save(leave);
    }

    // Update leave
    @PutMapping("/{id}")
    public Leave updateLeave(
            @PathVariable Long id,
            @Valid @RequestBody Leave updatedLeave) {

        Leave existing = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Leave not found"));

        existing.setEmployeeId(updatedLeave.getEmployeeId());
        existing.setLeaveType(updatedLeave.getLeaveType());
        existing.setStartDate(updatedLeave.getStartDate());
        existing.setEndDate(updatedLeave.getEndDate());
        existing.setReason(updatedLeave.getReason());

        return repository.save(existing);
    }

    // Approve leave
    @PutMapping("/{id}/approve")
    public Leave approveLeave(@PathVariable Long id) {
        Leave leave = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Leave not found"));

        leave.setStatus("Approved");
        return repository.save(leave);
    }

    // Reject leave
    @PutMapping("/{id}/reject")
    public Leave rejectLeave(@PathVariable Long id) {
        Leave leave = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Leave not found"));

        leave.setStatus("Rejected");
        return repository.save(leave);
    }

    // Delete leave
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteLeave(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Leave not found");
        }

        repository.deleteById(id);
    }
}
