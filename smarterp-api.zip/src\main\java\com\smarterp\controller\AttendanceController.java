
package com.smarterp.controller;

import com.smarterp.entity.Attendance;
import com.smarterp.repository.AttendanceRepository;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceRepository repository;

    public AttendanceController(AttendanceRepository repository) {
        this.repository = repository;
    }

    // Get all attendance records
    @GetMapping
    public List<Attendance> getAllAttendance() {
        return repository.findAll();
    }

    // Get attendance by ID
    @GetMapping("/{id}")
    public Attendance getAttendance(@PathVariable Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Attendance not found"));
    }

    // Get attendance by date
    @GetMapping("/date/{date}")
    public List<Attendance> getByDate(@PathVariable LocalDate date) {
        return repository.findByAttendanceDate(date);
    }

    // Get attendance by employee
    @GetMapping("/employee/{employeeId}")
    public List<Attendance> getByEmployee(
            @PathVariable Long employeeId) {
        return repository.findByEmployeeId(employeeId);
    }

    // Add attendance
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Attendance addAttendance(
            @Valid @RequestBody Attendance attendance) {
        attendance.setId(null);
        return repository.save(attendance);
    }

    // Update attendance
    @PutMapping("/{id}")
    public Attendance updateAttendance(
            @PathVariable Long id,
            @Valid @RequestBody Attendance updatedAttendance) {

        Attendance existing = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Attendance not found"));

        existing.setEmployeeId(updatedAttendance.getEmployeeId());
        existing.setAttendanceDate(updatedAttendance.getAttendanceDate());
        existing.setCheckIn(updatedAttendance.getCheckIn());
        existing.setCheckOut(updatedAttendance.getCheckOut());
        existing.setStatus(updatedAttendance.getStatus());

        return repository.save(existing);
    }

    // Delete attendance
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAttendance(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Attendance not found");
        }

        repository.deleteById(id);
    }
}
