package com.smarterp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @GetMapping("/")
    public String dashboard() {
        return "redirect:/index.html";
    }

    @GetMapping("/api/health")
    @org.springframework.web.bind.annotation.ResponseBody
    public String health() {
        return "SmartERP API is working!";
    }
}